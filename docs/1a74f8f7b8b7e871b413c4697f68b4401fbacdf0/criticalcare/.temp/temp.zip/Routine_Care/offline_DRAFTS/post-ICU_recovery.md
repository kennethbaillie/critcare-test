# Contacts

## Royal Infirmary of Edinburgh

Jo Thompson: 07725 058360

criticalcarerecovery.rie@nhslothian.scot.nhs.uk

Lucy Barclay: 07725 058360

criticalcarerecovery.rie@nhslothian.scot.nhs.uk


## Western General Hospital

Charlene Richardson: 07811 025994

wgh.criticalcarerecovery@nhslothian.scot.nhs.uk

## St John's Hospital

Ashley Crighton: 07811 026003

sjh.criticalcarerecovery@nhslothian.scot.nhs.uk


## Critical Care Recovery Service Lead

Judith Merriweather: judith.merriweather@nhslothian.scot.nhs.uk