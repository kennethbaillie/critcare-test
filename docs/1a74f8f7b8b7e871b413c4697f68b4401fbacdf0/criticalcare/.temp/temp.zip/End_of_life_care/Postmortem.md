
*All links below are on the intranet so they only work from NHS computers.*

[General PM website](http://intranet.lothian.scot.nhs.uk/Directory/mortuary/Pages/AdultHospitalPostMortem.aspx)

[Authorisation Form](http://intranet.lothian.scot.nhs.uk/Directory/mortuary/Adult%20Hospital%20Post%20Mortems/Adult%20Hospital%20Post%20Mortem%20Authorisation%20Form.pdf)
[Request Form](http://intranet.lothian.scot.nhs.uk/Directory/mortuary/Adult%20Hospital%20Post%20Mortems/Adult%20Hospital%20Post%20Mortem%20Request%20Form.pdf)
 
[Guidance for form completion](http://intranet.lothian.scot.nhs.uk/Directory/mortuary/Adult%20Hospital%20Post%20Mortems/Adult%20Hospital%20Post%20Mortem%20Guidance%20for%20Clinical%20Staff.pdf)
 
 